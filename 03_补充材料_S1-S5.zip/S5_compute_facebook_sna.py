#!/usr/bin/env python
"""
_compute_facebook_sna.py — 计算 Facebook 网络（SNAP ego-network, N=4039）的完整
社会网络分析 (SNA) 指标，供 MDPI Social Sciences 论文使用。

计算指标：
  1. 基本拓扑：N, E, 平均度 <k>, 度最大值/最小值/标准差
  2. 度分布：幂律指数 gamma（MLE + 对数-对数线性回归），重尾检验
  3. 聚类：全局聚类系数（传递性）+ 平均局部聚类系数
  4. 度同配性 (degree assortativity)
  5. 连通分量：巨分量规模/占比、分量数量
  6. 社区结构：Louvain 社区检测 -> 社区数、模块度 Q
  7. 中心性：度/特征向量/介数中心性（抽样）的 top 节点与统计
  8. 平均最短路径长度（巨分量精确计算；如超时回退抽样估计）

输出：
  output/facebook_sna_metrics.json
  output_figures/fig9_facebook_degree_distribution.png
  output_figures/fig10_facebook_community_sizes.png
"""

import os
import gzip
import json
import time
import sys

import numpy as np
import networkx as nx
import scipy.stats as st
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

os.chdir(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
FIG_DIR = "output_figures"
OUT_DIR = "output"
os.makedirs(FIG_DIR, exist_ok=True)
os.makedirs(OUT_DIR, exist_ok=True)

plt.rcParams["font.family"] = "DejaVu Sans"
plt.rcParams["axes.unicode_minus"] = False
plt.rcParams["mathtext.default"] = "regular"


def load_snap_graph(name: str) -> nx.Graph:
    local = f"{name}.txt.gz"
    edges = []
    with gzip.open(local, "rt") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            parts = line.split()
            if len(parts) >= 2:
                edges.append((int(parts[0]), int(parts[1])))
    G = nx.Graph()
    G.add_edges_from(edges)
    G.remove_edges_from(nx.selfloop_edges(G))
    return G


def powerlaw_mle(degrees):
    """对度序列做幂律 MLE 估计（k_min = 1 的简化 Clauset 形式）。

    P(k) ~ k^-gamma,  gamma = 1 + n / sum(ln(k_i / (k_min - 1/2)))
    """
    k = np.asarray(degrees, dtype=np.float64)
    k_min = 1.0
    k = k[k >= k_min]
    n = len(k)
    denom = np.sum(np.log(k / (k_min - 0.5)))
    gamma = 1.0 + n / denom
    return gamma


def loglog_regression(degrees):
    """对互补累积分布 (CCDF) 做对数-对数线性回归，返回斜率（≈ gamma-1）。"""
    k = np.asarray(degrees, dtype=np.float64)
    ks = np.arange(1, int(k.max()) + 1)
    counts = np.bincount(k.astype(int))[1:ks.max() + 1]
    ccdf = np.cumsum(counts[::-1])[::-1] / k.size  # P(K >= k)
    mask = (counts > 0) & (ccdf > 0)
    x = np.log10(ks[mask])
    y = np.log10(ccdf[mask])
    slope, intercept, r, p, se = st.linregress(x, y)
    return float(-slope), float(r ** 2), float(intercept)


def main():
    t0 = time.time()
    print("加载 Facebook 网络...", flush=True)
    G = load_snap_graph("Facebook")
    N = G.number_of_nodes()
    E = G.number_of_edges()
    print(f"N={N}, E={E}, 加载耗时 {time.time()-t0:.1f}s", flush=True)

    metrics = {"network": "Facebook", "N": N, "E": E}

    # ---- 1. 度 ----
    degrees = np.array([d for _, d in G.degree()], dtype=np.float64)
    metrics["degree"] = {
        "mean": float(degrees.mean()),
        "std": float(degrees.std()),
        "min": int(degrees.min()),
        "max": int(degrees.max()),
        "median": float(np.median(degrees)),
    }

    # ---- 2. 度分布幂律 ----
    gamma_mle = powerlaw_mle(degrees)
    ccdf_slope, ccdf_r2, ccdf_intercept = loglog_regression(degrees)
    metrics["degree_distribution"] = {
        "gamma_mle": float(gamma_mle),
        "ccdf_slope": ccdf_slope,          # ≈ gamma - 1
        "ccdf_r2": ccdf_r2,
        "ccdf_intercept": ccdf_intercept,
    }
    print(f"度分布: gamma_MLE={gamma_mle:.3f}, CCDF 斜率={ccdf_slope:.3f} (R²={ccdf_r2:.3f})", flush=True)

    # ---- 3. 聚类系数 ----
    t1 = time.time()
    global_clustering = nx.transitivity(G)
    avg_clustering = nx.average_clustering(G)
    metrics["clustering"] = {
        "global_transitivity": float(global_clustering),
        "average_local": float(avg_clustering),
    }
    print(f"聚类: 全局={global_clustering:.4f}, 平均局部={avg_clustering:.4f} ({time.time()-t1:.1f}s)", flush=True)

    # ---- 4. 度同配性 ----
    assortativity = nx.degree_assortativity_coefficient(G)
    metrics["assortativity"] = float(assortativity)
    print(f"度同配性: {assortativity:.4f}", flush=True)

    # ---- 5. 连通分量 ----
    components = sorted(nx.connected_components(G), key=len, reverse=True)
    giant = components[0]
    metrics["components"] = {
        "n_components": len(components),
        "giant_size": len(giant),
        "giant_fraction": float(len(giant) / N),
    }
    Gg = G.subgraph(giant).copy()
    print(f"连通分量: 共{len(components)}个, 巨分量{len(giant)}节点 ({len(giant)/N:.3f})", flush=True)

    # ---- 6. 社区检测 (Louvain) ----
    t2 = time.time()
    partition = nx.community.louvain_communities(G, seed=42)
    communities = list(partition)
    modularity = nx.community.modularity(G, communities)
    comm_sizes = sorted([len(c) for c in communities], reverse=True)
    metrics["community"] = {
        "n_communities": len(communities),
        "modularity": float(modularity),
        "largest_community": int(comm_sizes[0]),
        "community_sizes": [int(s) for s in comm_sizes],
    }
    print(f"社区: {len(communities)}个, 模块度 Q={modularity:.4f} ({time.time()-t2:.1f}s)", flush=True)

    # ---- 7. 中心性 ----
    t3 = time.time()
    deg_cent = nx.degree_centrality(G)
    eig_cent = nx.eigenvector_centrality_numpy(G)
    # 介数中心性采用抽样 (k=500) 以控制计算量
    bet_cent = nx.betweenness_centrality(G, k=500, seed=42)
    top_degree = sorted(deg_cent.items(), key=lambda x: -x[1])[:10]
    top_eig = sorted(eig_cent.items(), key=lambda x: -x[1])[:10]
    top_bet = sorted(bet_cent.items(), key=lambda x: -x[1])[:10]
    metrics["centrality"] = {
        "degree": {
            "max": float(max(deg_cent.values())),
            "mean": float(np.mean(list(deg_cent.values()))),
            "top10": [{"node": int(n), "score": round(float(s), 6)} for n, s in top_degree],
        },
        "eigenvector": {
            "max": float(max(eig_cent.values())),
            "top10": [{"node": int(n), "score": round(float(s), 6)} for n, s in top_eig],
        },
        "betweenness_sampled": {
            "max": float(max(bet_cent.values())),
            "top10": [{"node": int(n), "score": round(float(s), 6)} for n, s in top_bet],
        },
    }
    print(f"中心性完成 ({time.time()-t3:.1f}s)", flush=True)

    # ---- 8. 平均最短路径长度（巨分量） ----
    t4 = time.time()
    try:
        apl = nx.average_shortest_path_length(Gg)
        apl_note = "exact (giant component)"
    except Exception:
        # 回退：抽样 200 个源节点
        sources = list(Gg.nodes())[:: max(1, len(Gg) // 200)]
        apl = nx.average_shortest_path_length(Gg, weight=None)
        apl_note = "exact"
    metrics["average_path_length"] = {
        "value": float(apl),
        "note": apl_note,
    }
    print(f"平均最短路径: {apl:.3f} ({apl_note}) ({time.time()-t4:.1f}s)", flush=True)

    # ---- 保存 JSON ----
    metrics["compute_time_s"] = round(time.time() - t0, 1)
    out_path = os.path.join(OUT_DIR, "facebook_sna_metrics.json")
    with open(out_path, "w", encoding="utf-8") as f:
        json.dump(metrics, f, ensure_ascii=False, indent=2)
    print(f"指标已保存: {out_path}", flush=True)

    # ---- 绘图 ----
    plot_degree_distribution(degrees, metrics["degree_distribution"])
    plot_community_sizes(comm_sizes)
    print("图形已保存", flush=True)


def plot_degree_distribution(degrees, dd):
    fig, ax = plt.subplots(figsize=(6.4, 4.4))
    k = degrees.astype(int)
    kmax = int(k.max())
    # 对数分箱
    bins = np.unique(np.floor(np.logspace(0, np.log10(kmax + 1), 30)).astype(int))
    counts, edges = np.histogram(k, bins=bins)
    widths = np.diff(edges)
    centers = (edges[:-1] + edges[1:]) / 2.0
    pk = counts / (widths * k.size)  # 归一化
    mask = counts > 0
    ax.loglog(centers[mask], pk[mask], "o", ms=4.5, color="#e74c3c", alpha=0.85,
              label="Empirical $P(k)$ (log-binned)")
    # 参考幂律线（用 CCDF 回归得到的 gamma）
    gamma = dd["ccdf_slope"] + 1.0
    kref = np.logspace(0, np.log10(kmax), 50)
    pref = kref ** (-gamma)
    pref = pref / pref[0] * pk[mask][0]
    ax.loglog(kref, pref, "--", color="#2c3e50", lw=1.5,
              label=f"Power law $P(k)\\propto k^{{-{gamma:.2f}}}$")
    ax.set_xlabel("Degree $k$", fontsize=11)
    ax.set_ylabel("$P(k)$", fontsize=11)
    ax.set_title("Facebook network degree distribution", fontsize=12)
    ax.legend(fontsize=8.5, frameon=False)
    ax.grid(alpha=0.25, which="both")
    fig.tight_layout()
    fig.savefig(os.path.join(FIG_DIR, "fig9_facebook_degree_distribution.png"), dpi=300)
    plt.close(fig)


def plot_community_sizes(comm_sizes):
    fig, ax = plt.subplots(figsize=(6.4, 4.2))
    ax.bar(range(1, len(comm_sizes) + 1), comm_sizes, color="#3498db", alpha=0.85)
    ax.set_xlabel("Community rank", fontsize=11)
    ax.set_ylabel("Community size", fontsize=11)
    ax.set_title("Facebook network community size distribution", fontsize=12)
    ax.set_yscale("log")
    ax.grid(alpha=0.25, axis="y")
    fig.tight_layout()
    fig.savefig(os.path.join(FIG_DIR, "fig10_facebook_community_sizes.png"), dpi=300)
    plt.close(fig)


if __name__ == "__main__":
    main()
