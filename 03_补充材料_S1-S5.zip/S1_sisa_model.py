"""
sisa_model.py — SISa（带自我觉察的易感-感染-易感）传染病模型模拟器。

三仓室模型（离散时间，Monte Carlo 方法）用于模拟情绪在复杂网络中的传播：

  S  (0): 易感者       — 未受情绪影响，无自我觉察
  I  (1): 感染者       — 正在经历特定情绪状态，可向邻居传播
  Sa (2): 觉察易感者    — 曾恢复并获得自我觉察/心理韧性，有抵抗力

状态转移规则（每个时间步长 dt）：
  S  → I : 感染概率 = 1 - (1 - β)^(infectors) ≈ β × (infector_ratio) × dt
  I  → S : 自然恢复概率 = μ × dt
  I  → Sa: 觉察恢复概率 = α × dt（康复同时获得觉察）
  Sa → I : 再次感染概率 = β × (1 - awareness_protection) × (infector_ratio) × dt（觉察缓冲再影响）
  Sa → S : 觉察衰减概率 = δ × dt

实现特点：
  - 预计算邻接矩阵，向量化计算感染邻居数
  - 批量生成随机数，布尔掩码替换 Python 循环
  - 完整的状态轨迹和快照记录
  - 早期停止检测（传播消亡或达到稳定）
"""

import numpy as np
import networkx as nx
from typing import Dict, List, Tuple, Optional
from dataclasses import dataclass, field
from config import SISaConfig

# ===== 状态编码 =====
S_STATE = 0     # 易感者
I_STATE = 1     # 感染者
SA_STATE = 2    # 觉察易感者

STATE_NAMES = {S_STATE: "S", I_STATE: "I", SA_STATE: "Sa"}
STATE_COLORS_HEX = {S_STATE: "#2ecc71", I_STATE: "#e74c3c", SA_STATE: "#3498db"}


@dataclass
class SimulationSnapshot:
    """单个时间步骤的模拟快照。

    Attributes:
        step: 步骤序号。
        time: 模拟时间 (step × dt)。
        states: 各节点状态数组，shape (N,)，值为 {0,1,2}。
        n_susceptible: S 状态的节点数。
        n_infected: I 状态的节点数。
        n_aware: Sa 状态的节点数。
        infection_density: 感染密度 I/N。
        new_infections: 本步骤新增感染数。
        new_recoveries: 本步骤恢复数（I→S 和 I→Sa）。
    """
    step: int
    time: float
    states: np.ndarray
    n_susceptible: int
    n_infected: int
    n_aware: int
    infection_density: float
    new_infections: int
    new_recoveries: int = 0


@dataclass
class SimulationResult:
    """单次 SISa 模拟的完整结果。

    Attributes:
        config: SISa 模型配置。
        G: 网络图（带社区属性）。
        snapshots: 按时间步排列的快照列表。
        state_history: 完整状态轨迹，shape (recorded_steps, N)。
        density_history: 仓室密度轨迹，shape (recorded_steps, 3) — [S_density, I_density, Sa_density]。
        infection_times: 每个节点的首次感染步数，-1 表示从未感染。
    """
    config: SISaConfig
    G: nx.Graph
    snapshots: List[SimulationSnapshot] = field(default_factory=list)
    state_history: Optional[np.ndarray] = None
    density_history: Optional[np.ndarray] = None
    infection_times: Optional[np.ndarray] = None


class SISaModel:
    """SISa 传染病模型的离散时间 Monte Carlo 模拟器。

    使用高效的向量化 numpy 运算实现大规模网络的快速模拟。
    """

    def __init__(self, G: nx.Graph, config: SISaConfig):
        """
        Args:
            G: 带 'community' 节点属性的 networkx 图。
            config: SISa 模型参数配置。
        """
        self.G = G
        self.config = config
        self.N = G.number_of_nodes()

        # 节点ID与数组索引的映射
        self.nodes = sorted(G.nodes())
        self.node_to_idx = {node: i for i, node in enumerate(self.nodes)}
        self.idx_to_node = {i: node for i, node in enumerate(self.nodes)}

        # 预计算邻接矩阵（int8 节省内存）
        self.adj_matrix = nx.to_numpy_array(
            G, nodelist=self.nodes, dtype=np.int8
        )

        # 预计算每个节点的度（避免除零）
        self.degrees = np.array(
            [G.degree(n) for n in self.nodes], dtype=np.float32
        )
        self.degrees[self.degrees == 0] = 1  # 孤立节点保护

        # 独立随机数生成器（保证复现性）
        self.rng = np.random.default_rng(config.seed)

        self._logger = __import__('logging').getLogger('complex_network')

    def initialize_states(self) -> np.ndarray:
        """初始化节点状态，随机播种初始感染者和觉察者。

        Returns:
            states: shape (N,) 的数组，值为 {S_STATE, I_STATE, SA_STATE}。
        """
        states = np.full(self.N, S_STATE, dtype=np.int8)

        # 随机选择初始感染者
        n_initial_infected = max(1, int(self.N * self.config.initial_infected_fraction))
        infected_indices = self.rng.choice(self.N, size=n_initial_infected, replace=False)
        states[infected_indices] = I_STATE

        # 随机选择初始觉察者
        if self.config.initial_aware_fraction > 0:
            n_initial_aware = int(self.N * self.config.initial_aware_fraction)
            available = np.where(states == S_STATE)[0]
            if len(available) >= n_initial_aware:
                aware_indices = self.rng.choice(available, size=n_initial_aware, replace=False)
                states[aware_indices] = SA_STATE

        return states

    def _compute_infected_neighbor_counts(self, states: np.ndarray) -> np.ndarray:
        """向量化计算每个节点的感染邻居数。

        使用矩阵-向量乘法: adj @ infected_mask，时间复杂度 O(|E|)。

        Args:
            states: 当前状态数组。

        Returns:
            counts: 每个节点的感染邻居数，shape (N,)。
        """
        infected_mask = (states == I_STATE).astype(np.int8)
        return self.adj_matrix @ infected_mask

    def step(self, states: np.ndarray) -> Tuple[np.ndarray, int, int]:
        """执行一步 SISa 模型更新（Monte Carlo 离散时间步）。

        算法流程（全向量化）:
        1. 计算每个节点的感染邻居数
        2. 对每类节点批量生成随机数
        3. 使用布尔掩码同时更新所有节点状态

        Args:
            states: 当前状态数组，shape (N,)。

        Returns:
            (new_states, n_new_infections, n_new_recoveries)
        """
        dt = self.config.dt
        infected_counts = self._compute_infected_neighbor_counts(states)

        # 感染压力: β × (感染邻居数 / 度)
        infection_pressure = self.config.beta * infected_counts / self.degrees

        new_states = states.copy()
        n_new_infections = 0
        n_new_recoveries = 0

        # === S → I: 易感者被感染 ===
        s_mask = (states == S_STATE)
        if s_mask.any():
            p_infect = infection_pressure[s_mask] * dt
            p_infect = np.clip(p_infect, 0.0, 1.0)
            random_vals = self.rng.random(s_mask.sum())
            infect_mask_local = random_vals < p_infect
            s_indices = np.where(s_mask)[0]
            new_infected_indices = s_indices[infect_mask_local]
            new_states[new_infected_indices] = I_STATE
            n_new_infections += len(new_infected_indices)

        # === I → S 或 I → Sa: 感染者恢复 ===
        i_mask = (states == I_STATE)
        if i_mask.any():
            n_infected = i_mask.sum()
            random_vals = self.rng.random(n_infected)
            p_natural = self.config.mu * dt         # 自然恢复概率
            p_aware = self.config.alpha * dt         # 觉察恢复概率
            p_total = p_natural + p_aware
            # 竞争风险：按概率区间分配
            recover_to_s = random_vals < p_natural
            recover_to_sa = (random_vals >= p_natural) & (random_vals < p_total)
            i_indices = np.where(i_mask)[0]
            new_states[i_indices[recover_to_s]] = S_STATE
            new_states[i_indices[recover_to_sa]] = SA_STATE
            n_new_recoveries += recover_to_s.sum() + recover_to_sa.sum()

        # === Sa → S 或 Sa → I: 觉察者状态变化 ===
        sa_mask = (states == SA_STATE)
        if sa_mask.any():
            n_sa = sa_mask.sum()
            random_vals = self.rng.random(n_sa)
            p_decay = self.config.delta * dt          # 觉察衰减 → S
            # 觉察者再受影响率因觉察缓冲而降低（1 - awareness_protection 倍）
            p_reinfect = infection_pressure[sa_mask] * (1.0 - self.config.awareness_protection) * dt
            p_reinfect = np.clip(p_reinfect, 0.0, 1.0 - p_decay)
            sa_indices = np.where(sa_mask)[0]

            decay_mask = random_vals < p_decay
            new_states[sa_indices[decay_mask]] = S_STATE

            reinfect_mask = (random_vals >= p_decay) & (random_vals < p_decay + p_reinfect)
            new_states[sa_indices[reinfect_mask]] = I_STATE
            n_new_infections += reinfect_mask.sum()

        return new_states, n_new_infections, n_new_recoveries

    def run(self, record_interval: int = 1) -> SimulationResult:
        """运行完整的 SISa 模拟。

        模拟过程：
        1. 初始化状态
        2. 迭代执行 step() 最多 max_steps 次
        3. 每步记录快照
        4. 检测提前终止条件（传播消亡或达到稳定）

        Args:
            record_interval: 快照记录间隔（每 N 步记录一次以节省内存）。

        Returns:
            包含完整轨迹和元数据的 SimulationResult。
        """
        result = SimulationResult(config=self.config, G=self.G)
        states = self.initialize_states()

        # 首次感染时间追踪（-1 表示从未感染）
        infection_times = np.full(self.N, -1, dtype=int)
        initially_infected = (states == I_STATE)
        infection_times[initially_infected] = 0

        # 用于早期停止的状态追踪
        no_infection_streak = 0
        ever_had_infection = (states == I_STATE).any()
        steady_count = 0

        state_history_list = []
        density_history_list = []

        self._logger.info(f"SISa 模拟开始: N={self.N}, β={self.config.beta}, "
                          f"μ={self.config.mu}, α={self.config.alpha}, δ={self.config.delta}")

        for step_idx in range(self.config.max_steps):
            t = step_idx * self.config.dt

            # 记录状态（按间隔）
            if step_idx % record_interval == 0:
                n_s = int((states == S_STATE).sum())
                n_i = int((states == I_STATE).sum())
                n_sa = int((states == SA_STATE).sum())

                state_history_list.append(states.copy())
                density_history_list.append([n_s / self.N, n_i / self.N, n_sa / self.N])

            # 执行一步更新
            new_states, n_new_infections, n_new_recoveries = self.step(states)

            # 更新首次感染时间
            newly_infected = (states != I_STATE) & (new_states == I_STATE)
            infection_times[newly_infected] = step_idx + 1

            # 记录快照（始终记录以追踪关键事件）
            if step_idx % max(1, record_interval // 2) == 0 or n_new_infections > 0:
                n_s = int((new_states == S_STATE).sum())
                n_i = int((new_states == I_STATE).sum())
                n_sa = int((new_states == SA_STATE).sum())
                snap = SimulationSnapshot(
                    step=step_idx + 1,
                    time=(step_idx + 1) * self.config.dt,
                    states=new_states.copy(),
                    n_susceptible=n_s,
                    n_infected=n_i,
                    n_aware=n_sa,
                    infection_density=n_i / self.N,
                    new_infections=n_new_infections,
                    new_recoveries=n_new_recoveries,
                )
                result.snapshots.append(snap)

            states = new_states

            # 早期停止检测
            n_infected = int((states == I_STATE).sum())

            if n_infected == 0:
                if ever_had_infection:
                    no_infection_streak += 1
                if no_infection_streak > 50:
                    self._logger.info(f"传播已消亡，在第 {step_idx} 步停止。")
                    break
            else:
                ever_had_infection = True
                no_infection_streak = 0

            # 稳定性检测：感染密度在 100 步内波动小于 0.1%
            if step_idx > 200 and n_infected > 0:
                if len(result.snapshots) >= 100:
                    recent_densities = [
                        s.infection_density for s in result.snapshots[-100:]
                    ]
                    std_recent = np.std(recent_densities)
                    if std_recent < 0.001:
                        steady_count += 1
                    else:
                        steady_count = 0
                    if steady_count > 200:
                        self._logger.info(f"传播达到稳态，在第 {step_idx} 步停止。")
                        break

        # 组装结果
        result.state_history = np.array(state_history_list, dtype=np.int8)
        result.density_history = np.array(density_history_list, dtype=np.float32)
        result.infection_times = infection_times

        total_infected = int((infection_times >= 0).sum())
        self._logger.info(f"SISa 模拟完成: {len(result.snapshots)} 步记录, "
                          f"峰值感染密度={result.density_history[:, 1].max():.3f}, "
                          f"总感染节点={total_infected}/{self.N}")

        return result

    def run_with_initial_patient(
        self, patient_idx: int
    ) -> SimulationResult:
        """从指定节点开始传播的模拟。

        Args:
            patient_idx: 零号病人节点在内部索引数组中的位置（0-based）。

        Returns:
            模拟结果。若 patient_idx 无效则返回 None。
        """
        if patient_idx < 0 or patient_idx >= self.N:
            self._logger.error(f"无效的零号病人索引: {patient_idx}")
            return None

        result = SimulationResult(config=self.config, G=self.G)
        states = np.full(self.N, S_STATE, dtype=np.int8)
        states[patient_idx] = I_STATE

        infection_times = np.full(self.N, -1, dtype=int)
        infection_times[patient_idx] = 0

        state_history_list = []
        density_history_list = []

        for step_idx in range(self.config.max_steps):
            t = step_idx * self.config.dt

            if step_idx % 1 == 0:
                n_s = int((states == S_STATE).sum())
                n_i = int((states == I_STATE).sum())
                n_sa = int((states == SA_STATE).sum())
                state_history_list.append(states.copy())
                density_history_list.append([n_s / self.N, n_i / self.N, n_sa / self.N])

            new_states, n_new, n_rec = self.step(states)

            newly_infected = (states != I_STATE) & (new_states == I_STATE)
            infection_times[newly_infected] = step_idx + 1

            if step_idx % 5 == 0 or n_new > 0:
                n_s = int((new_states == S_STATE).sum())
                n_i = int((new_states == I_STATE).sum())
                n_sa = int((new_states == SA_STATE).sum())
                snap = SimulationSnapshot(
                    step=step_idx + 1,
                    time=(step_idx + 1) * self.config.dt,
                    states=new_states.copy(),
                    n_susceptible=n_s,
                    n_infected=n_i,
                    n_aware=n_sa,
                    infection_density=n_i / self.N,
                    new_infections=n_new,
                    new_recoveries=n_rec,
                )
                result.snapshots.append(snap)

            states = new_states

            n_i = int((states == I_STATE).sum())
            if n_i == 0 and step_idx > 50:
                break

        result.state_history = np.array(state_history_list, dtype=np.int8)
        result.density_history = np.array(density_history_list, dtype=np.float32)
        result.infection_times = infection_times

        return result


def get_state_color(state: int) -> str:
    """获取状态对应的颜色。

    Args:
        state: 状态值 (0, 1, 或 2)。

    Returns:
        十六进制颜色字符串。
    """
    return STATE_COLORS_HEX.get(state, "#95a5a6")


def get_state_name(state: int) -> str:
    """获取状态对应的名称。

    Args:
        state: 状态值 (0, 1, 或 2)。

    Returns:
        状态名称字符串。
    """
    return STATE_NAMES.get(state, "Unknown")
