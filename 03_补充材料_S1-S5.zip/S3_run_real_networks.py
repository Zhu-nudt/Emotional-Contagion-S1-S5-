#!/usr/bin/env python
"""
run_real_networks.py — 以真实网络为基准，运行 SISa 模型并输出结果。

在三个公开真实网络（Facebook、ca-GrQc、email-Eu-core）上运行 SISa 三仓室
情绪传播模型，与 LFR 基准网络在相同默认参数下进行传播动力学比对。

复用 sisa_model.SISaModel 的完整模拟逻辑（状态转移规则、向量化 Monte Carlo、
早期停止检测均保持不变），唯一改动是将稠密邻接矩阵替换为 scipy.sparse 稀疏
矩阵（float32），以便在 N=4000~5000 的真实网络上高效运行，同时避免 int8 邻接
矩阵在高度节点上的计数溢出。对于 LFR（最大度 47）该改动不改变任何结果。

输出：
  output_figures/fig7_real_networks.png          — 各网络感染密度时间序列
  output_figures/fig8_real_networks_bars.png     — 峰值/稳态感染密度对比柱状图
  output/real_network_benchmark_metrics.json      — 全部指标（含均值/95%CI）
"""

import os
import gzip
import json
import time
import sys

import numpy as np
import networkx as nx
import scipy.sparse as sp
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

from config import LFRConfig, SISaConfig
from lfr_network import generate_lfr_network
from sisa_model import SISaModel, S_STATE, I_STATE, SA_STATE

os.chdir(os.path.dirname(os.path.abspath(__file__)))
FIG_DIR = "output_figures"
OUT_DIR = "output"
os.makedirs(FIG_DIR, exist_ok=True)
os.makedirs(OUT_DIR, exist_ok=True)

# English fonts (consistent with regen_figures_v4.py)
plt.rcParams["font.family"] = "DejaVu Sans"
plt.rcParams["axes.unicode_minus"] = False
plt.rcParams["mathtext.default"] = "regular"

N_TRIALS = 30          # 每网络独立试验次数（均值与 95% CI）
MAX_STEPS = 4000       # 4000 × 0.05 = 200 时间单位，保证稀疏网络（ca-GrQc）越过峰值
DT = 0.05


def load_snap_graph(name: str) -> nx.Graph:
    """从本地 .txt.gz 加载 SNAP 网络（无向、去自环）。"""
    local = f"{name}.txt.gz"
    edges = []
    with gzip.open(local, "rt") as f:
        for line in f:
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            parts = line.split()
            if len(parts) >= 2:
                edges.append((int(parts[0]), int(parts[1])))
    G = nx.Graph()
    G.add_edges_from(edges)
    G.remove_edges_from(nx.selfloop_edges(G))
    return G


def run_one_trial(G: nx.Graph, cfg: SISaConfig):
    """在给定网络上运行一次 SISa 模拟，返回密度轨迹与关键指标。

    复用 SISaModel.run() 的完整逻辑；仅将邻接矩阵替换为稀疏 float32，
    以保证大网络可算且不产生 int8 计数溢出。
    """
    model = SISaModel(G, cfg)
    dense = nx.to_numpy_array(G, nodelist=model.nodes, dtype=np.float32)
    model.adj_matrix = sp.csr_matrix(dense)  # 稀疏加速，数学等价
    result = model.run(record_interval=1)

    dh = result.density_history              # (steps, 3) = [S, I, Sa]
    t = np.arange(dh.shape[0], dtype=np.float64) * DT
    I = dh[:, 1].astype(np.float64)
    Sa = dh[:, 2].astype(np.float64)

    i_max = float(I.max())
    t_peak = float(t[int(np.argmax(I))])
    n_ss = max(50, int(0.2 * dh.shape[0]))   # 稳态：末 20% 轨迹
    I_ss = float(np.mean(I[-n_ss:]))
    Sa_ss = float(np.mean(Sa[-n_ss:]))
    Sa_max = float(Sa.max())
    idx10 = np.where(I >= 0.10)[0]
    t10 = float(t[idx10[0]]) if len(idx10) > 0 else None
    ever = float((result.infection_times >= 0).mean())

    return t, I, Sa, dict(
        i_max=i_max, t_peak=t_peak, I_ss=I_ss, Sa_ss=Sa_ss,
        Sa_max=Sa_max, t10=t10, ever=ever,
    )


def run_benchmark(G: nx.Graph, name: str, seed_base: int):
    """对单个网络运行 N_TRIALS 次，返回汇总（时间网格 + 均值/CI + 指标）。"""
    print(f"\n[{name}] N={G.number_of_nodes()}, E={G.number_of_edges()}，"
          f"{N_TRIALS} 次试验...", flush=True)
    t0 = time.time()

    t_grid = np.linspace(0.0, MAX_STEPS * DT, 500)
    I_matrix = np.zeros((N_TRIALS, len(t_grid)))
    Sa_matrix = np.zeros((N_TRIALS, len(t_grid)))
    metric_list = []

    for k in range(N_TRIALS):
        cfg = SISaConfig()
        cfg.seed = seed_base + k * 1000
        cfg.max_steps = MAX_STEPS
        t, I, Sa, m = run_one_trial(G, cfg)
        I_matrix[k] = np.interp(t_grid, t, I)
        Sa_matrix[k] = np.interp(t_grid, t, Sa)
        metric_list.append(m)

    I_mean = I_matrix.mean(axis=0)
    I_ci = 1.96 * I_matrix.std(axis=0) / np.sqrt(N_TRIALS)
    Sa_mean = Sa_matrix.mean(axis=0)

    # 指标均值与 95% CI（基于 t 分布近似：1.96 * SEM）
    summary = {}
    for key in metric_list[0]:
        vals = np.array([m[key] for m in metric_list], dtype=np.float64)
        summary[key] = {
            "mean": float(vals.mean()),
            "std": float(vals.std()),
            "ci95": float(1.96 * vals.std() / np.sqrt(N_TRIALS)),
        }

    print(f"  I_max={summary['i_max']['mean']:.3f}±{summary['i_max']['ci95']:.3f}, "
          f"I_ss={summary['I_ss']['mean']:.3f}±{summary['I_ss']['ci95']:.3f}, "
          f"t_peak={summary['t_peak']['mean']:.1f}, "
          f"t10={summary['t10']['mean']:.1f}, "
          f"ever={summary['ever']['mean']:.3f}  ({time.time()-t0:.1f}s)", flush=True)

    return dict(
        name=name,
        N=G.number_of_nodes(),
        E=G.number_of_edges(),
        t_grid=t_grid.tolist(),
        I_mean=I_mean.tolist(),
        I_ci=I_ci.tolist(),
        Sa_mean=Sa_mean.tolist(),
        metrics=summary,
    )


def main():
    # 1. 真实网络
    real_names = ["Facebook", "email-Eu-core"]
    real_graphs = {n: load_snap_graph(n) for n in real_names}

    # 2. LFR 基准网络（与论文同一配置，验证边数）
    lfr = generate_lfr_network(LFRConfig())
    print(f"[LFR] 生成网络: N={lfr.number_of_nodes()}, E={lfr.number_of_edges()}")

    # 3. 逐网运行
    bench = {}
    bench["LFR"] = run_benchmark(lfr, "LFR", seed_base=123)
    for i, name in enumerate(real_names):
        bench[name] = run_benchmark(real_graphs[name], name, seed_base=123)

    # 4. 保存指标 JSON
    metrics_path = os.path.join(OUT_DIR, "real_network_benchmark_metrics.json")
    with open(metrics_path, "w", encoding="utf-8") as f:
        json.dump(bench, f, ensure_ascii=False, indent=2)
    print(f"\n指标已保存: {metrics_path}")

    # 5. 绘图
    plot_timeseries(bench)
    plot_bars(bench)
    print("图形已保存到 output_figures/")


def plot_timeseries(bench):
    colors = {"LFR": "#2c3e50", "Facebook": "#e74c3c",
              "email-Eu-core": "#2980b9"}
    order = ["LFR", "Facebook", "email-Eu-core"]
    fig, ax = plt.subplots(figsize=(7.2, 4.6))
    for name in order:
        b = bench[name]
        t = np.array(b["t_grid"])
        I_mean = np.array(b["I_mean"])
        I_ci = np.array(b["I_ci"])
        ax.plot(t, I_mean, color=colors[name], lw=2.0, label=name)
        ax.fill_between(t, I_mean - I_ci, I_mean + I_ci,
                        color=colors[name], alpha=0.18, linewidth=0)
    ax.set_xlabel("Time $t$ (t.u.)", fontsize=11)
    ax.set_ylabel("Infected density $I(t)$", fontsize=11)
    ax.set_title("SISa propagation dynamics: real networks vs. LFR benchmark", fontsize=12)
    ax.set_xlim(0, MAX_STEPS * DT)
    ax.set_ylim(bottom=0)
    ax.legend(fontsize=9, frameon=False)
    ax.grid(alpha=0.25)
    fig.tight_layout()
    fig.savefig(os.path.join(FIG_DIR, "fig7_real_networks.png"), dpi=200)
    plt.close(fig)


def plot_bars(bench):
    order = ["LFR", "Facebook", "email-Eu-core"]
    labels = ["LFR", "Facebook", "email-Eu-core"]
    i_max_mean = [bench[n]["metrics"]["i_max"]["mean"] for n in order]
    i_max_ci = [bench[n]["metrics"]["i_max"]["ci95"] for n in order]
    i_ss_mean = [bench[n]["metrics"]["I_ss"]["mean"] for n in order]
    i_ss_ci = [bench[n]["metrics"]["I_ss"]["ci95"] for n in order]

    x = np.arange(len(order))
    w = 0.36
    fig, ax = plt.subplots(figsize=(6.6, 4.4))
    b1 = ax.bar(x - w / 2, i_max_mean, w, yerr=i_max_ci, capsize=4,
                color="#e74c3c", label="Peak infection density $I_{\\max}$")
    b2 = ax.bar(x + w / 2, i_ss_mean, w, yerr=i_ss_ci, capsize=4,
                color="#3498db", label="Steady-state infection density $I_{ss}$")
    ax.set_xticks(x)
    ax.set_xticklabels(labels, fontsize=10)
    ax.set_ylabel("Infection density", fontsize=11)
    ax.set_title("Peak and steady-state infection density", fontsize=12)
    ax.set_ylim(0, max(i_max_mean) * 1.2)
    ax.legend(fontsize=9, frameon=False)
    ax.grid(axis="y", alpha=0.25)
    fig.tight_layout()
    fig.savefig(os.path.join(FIG_DIR, "fig8_real_networks_bars.png"), dpi=200)
    plt.close(fig)


if __name__ == "__main__":
    main()
