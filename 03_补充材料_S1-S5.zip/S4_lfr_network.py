"""
lfr_network.py — LFR 基准网络生成与验证。

LFR (Lancichinetti-Fortunato-Radicchi) 网络是社区检测领域的标准基准模型，
能够生成同时具有以下特性的真实复杂网络：
  - 幂律度分布 (tau1 控制)
  - 幂律社区大小分布 (tau2 控制)
  - 可调的社区混合程度 (mu 控制)
  - 预设的平均度和最大度

使用 networkx 内置的 LFR_benchmark_graph 实现，纯 Python，无需外部 C++ 工具。
"""

import networkx as nx
import numpy as np
from typing import Dict, List, Set, Tuple, Optional
from config import LFRConfig
from utils import set_seed


def generate_lfr_network(config: LFRConfig) -> nx.Graph:
    """生成 LFR 基准网络。

    使用 networkx 的 LFR_benchmark_graph 生成具有社区结构的复杂网络。
    每节点被赋予单一的 community 属性（取重叠社区列表的第一个）。

    Args:
        config: LFR 网络参数配置。

    Returns:
        带有 'community' 节点属性的 networkx Graph 对象。

    Raises:
        RuntimeError: 如果 LFR 生成失败（通常是参数组合不合理）。
    """
    set_seed(config.seed)
    logger = __import__('logging').getLogger('complex_network')

    logger.info(f"正在生成 LFR 网络: N={config.n}, μ={config.mu}, "
                f"<k>={config.average_degree}, max_degree={config.max_degree}")

    try:
        G = nx.generators.community.LFR_benchmark_graph(
            n=config.n,
            tau1=config.tau1,
            tau2=config.tau2,
            mu=config.mu,
            average_degree=config.average_degree,
            max_degree=config.max_degree,
            min_community=config.min_community,
            max_community=config.max_community,
            seed=config.seed,
        )
    except Exception as e:
        raise RuntimeError(
            f"LFR 网络生成失败: {e}\n"
            f"提示: 尝试调整参数组合，例如降低 max_degree 或增加 min_community。"
        ) from e

    # LFR_benchmark_graph 返回的节点 community 属性是 frozenset（支持重叠社区）
    # 本项目中我们使用单一社区归属，取第一个标签
    community_map = {}
    for node in G.nodes():
        comm_set = G.nodes[node]['community']
        if isinstance(comm_set, (frozenset, set)):
            # 取第一个（或唯一一个）社区ID
            comm_id = next(iter(comm_set))
        else:
            comm_id = int(comm_set)
        community_map[node] = comm_id
    nx.set_node_attributes(G, community_map, 'community')

    # 确保节点ID是整数
    G = nx.convert_node_labels_to_integers(G, label_attribute='orig_id')

    # 移除孤立节点（度=0），它们不会参与传播
    isolated = [n for n in G.nodes() if G.degree(n) == 0]
    if isolated:
        logger.warning(f"发现 {len(isolated)} 个孤立节点，已移除。")
        G.remove_nodes_from(isolated)

    logger.info(f"LFR 网络生成完成: {G.number_of_nodes()} 节点, "
                f"{G.number_of_edges()} 边")

    return G


def validate_lfr_network(G: nx.Graph, config: LFRConfig) -> Dict[str, float]:
    """验证生成的 LFR 网络是否符合预期属性。

    检查项：
      - 节点数和边数
      - 实际平均度 vs 目标平均度
      - 社区数量
      - 网络模块度 (modularity)
      - 估计的社区混合比例

    Args:
        G: 生成的网络。
        config: 用于对比的 LFR 配置。

    Returns:
        包含各验证指标的字典。
    """
    N = G.number_of_nodes()
    E = G.number_of_edges()
    degrees = [d for _, d in G.degree()]
    avg_degree = np.mean(degrees)
    max_degree = max(degrees)

    # 获取社区划分
    communities = get_community_structure(G)
    n_communities = len(communities)

    # 计算模块度 Q
    community_list = [get_community_labels(G)[n] for n in G.nodes()]
    try:
        Q = nx.community.modularity(G, [
            set([n for n in G.nodes() if get_community_labels(G)[n] == c])
            for c in set(community_list)
        ])
    except Exception:
        Q = float('nan')

    # 计算社区混合比例
    intra, inter = get_intra_inter_edges(G)
    mixing_estimate = inter / (intra + inter) if (intra + inter) > 0 else 0.0

    return {
        'n_nodes': N,
        'n_edges': E,
        'avg_degree': avg_degree,
        'max_degree': max_degree,
        'target_avg_degree': config.average_degree,
        'n_communities': n_communities,
        'modularity': Q,
        'mixing_estimate': mixing_estimate,
        'target_mixing': config.mu,
        'intra_edges': intra,
        'inter_edges': inter,
    }


def get_community_labels(G: nx.Graph) -> Dict[int, int]:
    """从节点属性中提取社区标签。

    Args:
        G: 带 'community' 节点属性的图。

    Returns:
        字典: node_id -> community_id。
    """
    return {n: G.nodes[n]['community'] for n in G.nodes()}


def get_community_structure(G: nx.Graph) -> Dict[int, Set[int]]:
    """构建社区到节点集合的映射。

    Args:
        G: 带 'community' 节点属性的图。

    Returns:
        字典: community_id -> {属于该社区的 node_id 集合}。
    """
    communities: Dict[int, Set[int]] = {}
    for node in G.nodes():
        comm = G.nodes[node]['community']
        if comm not in communities:
            communities[comm] = set()
        communities[comm].add(node)
    return communities


def get_intra_inter_edges(G: nx.Graph) -> Tuple[int, int]:
    """统计社区内边和社区间边的数量。

    社区内边：两端节点属于同一社区。
    社区间边：两端节点属于不同社区。

    Args:
        G: 带 'community' 节点属性的图。

    Returns:
        (intra_count, inter_count) 元组。
    """
    community_labels = get_community_labels(G)
    intra_count = 0
    inter_count = 0
    for u, v in G.edges():
        if community_labels.get(u) == community_labels.get(v):
            intra_count += 1
        else:
            inter_count += 1
    return intra_count, inter_count


def get_community_sizes(G: nx.Graph) -> Dict[int, int]:
    """获取每个社区的大小。

    Args:
        G: 带 'community' 节点属性的图。

    Returns:
        字典: community_id -> 社区内节点数量。
    """
    communities = get_community_structure(G)
    return {c: len(members) for c, members in communities.items()}


def get_community_edges_matrix(G: nx.Graph) -> np.ndarray:
    """构建社区间的边数矩阵。

    返回矩阵 M，其中 M[i][j] = 社区 i 和社区 j 之间的边数。
    对角线元素 M[i][i] = 社区 i 内部的边数。

    Args:
        G: 带 'community' 节点属性的图。

    Returns:
        对称的 (C × C) numpy 数组，C 为社区数。
    """
    community_labels = get_community_labels(G)
    communities = get_community_structure(G)
    comm_list = sorted(communities.keys())
    C = len(comm_list)
    comm_to_idx = {c: i for i, c in enumerate(comm_list)}

    M = np.zeros((C, C), dtype=int)
    for u, v in G.edges():
        cu = community_labels[u]
        cv = community_labels[v]
        i = comm_to_idx[cu]
        j = comm_to_idx[cv]
        M[i, j] += 1
        if i != j:
            M[j, i] += 1

    return M


def print_network_summary(G: nx.Graph, config: LFRConfig) -> None:
    """打印网络统计摘要。

    Args:
        G: 生成的网络。
        config: LFR 配置（用于对比目标值）。
    """
    stats = validate_lfr_network(G, config)
    print("\n" + "=" * 55)
    print("  LFR 基准网络统计摘要")
    print("=" * 55)
    print(f"  节点数:           {stats['n_nodes']}")
    print(f"  边数:             {stats['n_edges']}")
    print(f"  平均度:           {stats['avg_degree']:.2f} (目标: {stats['target_avg_degree']})")
    print(f"  最大度:           {stats['max_degree']}")
    print(f"  社区数:           {stats['n_communities']}")
    print(f"  模块度 Q:         {stats['modularity']:.4f}")
    print(f"  混合比例估计:     {stats['mixing_estimate']:.3f} (目标 μ={stats['target_mixing']})")
    print(f"  社区内边/社区间边: {stats['intra_edges']} / {stats['inter_edges']}")
    print("=" * 55 + "\n")
