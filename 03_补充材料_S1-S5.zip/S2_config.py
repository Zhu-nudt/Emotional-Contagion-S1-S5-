"""
config.py — 所有可配置参数的集中管理中心。

每个可调参数集中于此文件，便于复现实验和参数敏感性分析。
可通过 CLI 参数或 JSON 配置文件覆盖默认值。
"""

from dataclasses import dataclass, field
from typing import Optional, Dict, Any


@dataclass
class LFRConfig:
    """LFR 基准网络参数。

    LFR (Lancichinetti-Fortunato-Radicchi) 网络是社区检测算法的基准生成模型，
    能够生成具有幂律度分布和幂律社区大小分布的现实复杂网络。

    Attributes:
        n: 节点总数。500 节点在计算效率和网络复杂性之间取得了平衡。
        tau1: 度分布幂律指数 (>1)。3.0 生成少数高度 hub 节点，符合社会网络特征。
        tau2: 社区大小分布幂律指数 (>1)。1.5 生成大小不均的社区结构。
        mu: 混合参数，控制跨社区边的比例。0.15 表示约 15% 的边是跨社区的。
        average_degree: 目标平均度。12 保证足够的连边密度。
        max_degree: 最大度，截断度分布的上界。60 避免出现极端 hub。
        min_community: 最小社区大小。20 保证每个社区有足够的内部结构。
        max_community: 最大社区大小。100 不会出现过于庞大的单一社区。
        seed: 随机种子，保证网络生成的复现性。
    """
    n: int = 500
    tau1: float = 3.0
    tau2: float = 1.5
    mu: float = 0.15
    average_degree: float = 12.0
    max_degree: int = 60
    min_community: int = 20
    max_community: int = 100
    seed: int = 42


@dataclass
class SISaConfig:
    """SISa 传染病模型参数。

    SISa (Susceptible-Infected-Susceptible with awareness) 模型包含三个仓室：
      S  (0): 易感者 — 未受情绪影响，无自我觉察
      I  (1): 感染者 — 正在经历特定情绪状态，可传播给邻居
      Sa (2): 觉察易感者 — 曾恢复并获得自我觉察，有一定心理韧性

    状态转移：
      S  → I : β * (感染邻居比例) — 被情绪感染
      I  → S : μ — 自然恢复（情绪消退/调节），回到完全易感态
      I  → Sa: α — 恢复并形成心理觉察/韧性
      Sa → I : β * (1 - awareness_protection) * (感染邻居比例) — 再次被感染（觉察起缓冲作用）
      Sa → S : δ — 觉察消退，回归普通易感状态（缓冲随之消失）

    Attributes:
        beta: 感染率。控制情绪的传染力。0.35 保证足够的传播动力。
        mu: 自然恢复率。0.10 表示平均 10 个时间单位后自然恢复。
        alpha: 觉察促进恢复率。感染者同时获得觉察并恢复的速率。0.08。
        delta: 觉察衰减率。觉察随时间消退的速率。0.02 表示觉察较为持久。
        awareness_protection: 觉察保护因子（0~1）。觉察者再受影响率 = β × (1 - awareness_protection)；
            0.5 表示觉察使个体对再影响的易感性降低一半，刻画"调节能力缓冲情绪影响"的心理机制。
        initial_infected_fraction: 初始感染者比例。2% = 10 个初始感染节点（N=500时）。
        initial_aware_fraction: 初始觉察者比例。0% 表示无人事先有觉察。
        dt: 离散时间步长。0.05 在精度和速度间取得平衡。
        max_steps: 最大模拟步数。2000 × 0.05 = 100 个有效时间单位。
        seed: 随机种子，保证模拟复现性。
    """
    beta: float = 0.35
    mu: float = 0.10
    alpha: float = 0.08
    delta: float = 0.02
    awareness_protection: float = 0.5
    initial_infected_fraction: float = 0.02
    initial_aware_fraction: float = 0.0
    dt: float = 0.05
    max_steps: int = 2000
    seed: int = 123


@dataclass
class VizConfig:
    """可视化参数。

    Attributes:
        animation_fps: 保存的动画帧率。
        animation_dpi: 保存的动画分辨率。
        animation_interval_ms: 动画播放时的帧间隔（毫秒）。
        node_size: 网络图中节点大小。
        infected_color: 感染者 (I) 的节点颜色 — 红色警示。
        susceptible_color: 易感者 (S) 的节点颜色 — 绿色健康。
        aware_color: 觉察者 (Sa) 的节点颜色 — 蓝色保护。
        edge_color: 边的颜色。
        community_cmap: 社区着色方案（matplotlib colormap 名称）。
        output_dir: 所有可视化输出的目录。
    """
    animation_fps: int = 10
    animation_dpi: int = 100
    animation_interval_ms: int = 100
    node_size: int = 20
    infected_color: str = "#e74c3c"
    susceptible_color: str = "#2ecc71"
    aware_color: str = "#3498db"
    edge_color: str = "#bdc3c7"
    background_color: str = "#1a1a2e"
    community_cmap: str = "tab20"
    output_dir: str = "./output"


@dataclass
class SimulationConfig:
    """顶层模拟配置，组合所有子配置。

    Attributes:
        lfr: LFR 网络参数。
        sisa: SISa 模型参数。
        viz: 可视化参数。
        num_trials: 独立模拟试验次数。多次运行可获得统计均值与方差。
        save_results: 是否保存原始模拟结果为 .npz 文件。
        save_network: 是否保存网络为 GraphML 格式。
        verbose: 是否输出详细日志。
    """
    lfr: LFRConfig = field(default_factory=LFRConfig)
    sisa: SISaConfig = field(default_factory=SISaConfig)
    viz: VizConfig = field(default_factory=VizConfig)
    num_trials: int = 3
    save_results: bool = True
    save_network: bool = True
    verbose: bool = True

    @classmethod
    def from_dict(cls, d: Dict[str, Any]) -> "SimulationConfig":
        """从嵌套字典构建配置（例如从 JSON 加载）。"""
        lfr_cfg = LFRConfig(**d.get("lfr", {}))
        sisa_cfg = SISaConfig(**d.get("sisa", {}))
        viz_cfg = VizConfig(**d.get("viz", {}))
        return cls(
            lfr=lfr_cfg,
            sisa=sisa_cfg,
            viz=viz_cfg,
            num_trials=d.get("num_trials", 3),
            save_results=d.get("save_results", True),
            save_network=d.get("save_network", True),
            verbose=d.get("verbose", True),
        )

    def to_dict(self) -> Dict[str, Any]:
        """将配置序列化为字典以便保存为 JSON。"""
        return {
            "lfr": self.lfr.__dict__,
            "sisa": self.sisa.__dict__,
            "viz": self.viz.__dict__,
            "num_trials": self.num_trials,
            "save_results": self.save_results,
            "save_network": self.save_network,
            "verbose": self.verbose,
        }


# ===== 预设配置方案 =====

def preset_default() -> SimulationConfig:
    """默认配置：N=500，适用于社会群体情绪传播研究场景。"""
    return SimulationConfig()


def preset_high_infection() -> SimulationConfig:
    """高感染率方案：β=0.5，模拟更易传播的情绪。"""
    cfg = SimulationConfig()
    cfg.sisa.beta = 0.5
    cfg.sisa.mu = 0.08
    return cfg


def preset_resilient() -> SimulationConfig:
    """高韧性方案：α=0.15，模拟觉察/心理韧性较强的社会群体。"""
    cfg = SimulationConfig()
    cfg.sisa.alpha = 0.15
    cfg.sisa.delta = 0.01
    return cfg


def preset_small_network() -> SimulationConfig:
    """小规模网络：N=200，快速测试用。"""
    cfg = SimulationConfig()
    cfg.lfr.n = 200
    cfg.lfr.max_degree = 40
    cfg.lfr.min_community = 15
    cfg.lfr.max_community = 50
    cfg.sisa.max_steps = 1000
    return cfg


def preset_large_network() -> SimulationConfig:
    """大规模网络：N=1000，获得更多统计数据。"""
    cfg = SimulationConfig()
    cfg.lfr.n = 1000
    cfg.lfr.max_degree = 100
    cfg.lfr.max_community = 150
    cfg.sisa.max_steps = 3000
    return cfg
